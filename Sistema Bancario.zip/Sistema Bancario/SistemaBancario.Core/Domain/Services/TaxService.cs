using System;
using SistemaBancario.Core.Domain.ValueObjects;

namespace SistemaBancario.Core.Domain.Services
{
    public class TaxService
    {
        private readonly decimal _withholdingTaxRate;

        /// <summary>
        /// Withholding tax rate (e.g., 0.15 for 15%).
        /// </summary>
        public TaxService(decimal withholdingTaxRate = 0.15m)
        {
            if (withholdingTaxRate < 0 || withholdingTaxRate > 1)
                 throw new ArgumentException("Tax rate must be between 0 and 1.");
            
            _withholdingTaxRate = withholdingTaxRate;
        }

        public Money CalculateTax(Money earnings)
        {
            if (earnings.Amount <= 0) return Money.Zero(earnings.Currency);

            decimal taxAmount = earnings.Amount * _withholdingTaxRate;
            
            // Rounding up/down rules depend on jurisdiction. Using standard round to even here.
            return new Money(Math.Round(taxAmount, 2, MidpointRounding.ToEven), earnings.Currency);
        }
    }
}
