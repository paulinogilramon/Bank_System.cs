using System;
using SistemaBancario.Core.Domain.ValueObjects;

namespace SistemaBancario.Core.Domain.Services
{
    public enum CompoundingFrequency
    {
        Annually = 1,
        SemiAnnually = 2,
        Quarterly = 4,
        Monthly = 12,
        Daily = 365
    }

    public class InterestService
    {
        /// <summary>
        /// Calculates the compound interest earned.
        /// Formula: Interest = P * (1 + r/n)^(n*t) - P
        /// </summary>
        /// <param name="principal">The initial amount (P).</param>
        /// <param name="rate">The annual interest rate (r).</param>
        /// <param name="timeInYears">The time the money is invested or borrowed for, in years (t).</param>
        /// <param name="frequency">The number of times that interest is compounded per year (n).</param>
        /// <returns>The calculated Interest amount.</returns>
        public Money CalculateCompoundInterest(Money principal, InterestRate rate, double timeInYears, CompoundingFrequency frequency)
        {
            if (principal.Amount < 0)
                throw new ArgumentException("Principal cannot be negative.", nameof(principal));
            if (timeInYears < 0)
                throw new ArgumentException("Time cannot be negative.", nameof(timeInYears));

            decimal P = principal.Amount;
            decimal r = rate.Value;
            int n = (int)frequency;
            double t = timeInYears;

            double baseFactor = 1 + ((double)r / n);
            double exponent = n * t;
            
            // Standard decimal pow can lose precision for finance, but for interest simple calc it's often acceptable.
            // For strict robustness, we might want iterative multiplication or a high-precision library.
            // using Math.Pow which returns double, then casting back to decimal.
            
            decimal amountXY = (decimal)Math.Pow(baseFactor, exponent);
            decimal finalAmount = P * amountXY;
            decimal interestOnly = finalAmount - P;

            // Rounding to 2 decimal places (standard banking). 
            // In a real high-frequency system, we might carry more precision.
            return new Money(Math.Round(interestOnly, 2, MidpointRounding.ToEven), principal.Currency); 
        }
    }
}
