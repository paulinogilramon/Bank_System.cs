using System;
using System.Collections.Generic;
using System.Linq;
using SistemaBancario.Core.Domain.ValueObjects;

namespace SistemaBancario.Core.Domain.Accounting
{
    public class JournalEntry
    {
        public Guid Id { get; }
        public DateTime BookingDate { get; }
        public string Description { get; }
        private readonly List<EntryLine> _lines;
        public IReadOnlyList<EntryLine> Lines => _lines.AsReadOnly();

        public JournalEntry(string description, DateTime bookingDate)
        {
            if (string.IsNullOrWhiteSpace(description))
                throw new ArgumentException("Description cannot be empty.", nameof(description));

            Id = Guid.NewGuid();
            Description = description;
            BookingDate = bookingDate;
            _lines = new List<EntryLine>();
        }

        public void AddLine(EntryLine line)
        {
            if (line == null) throw new ArgumentNullException(nameof(line));
            
            // Ensure connection to existing lines currency if any
            if (_lines.Any() && _lines.First().Amount.Currency != line.Amount.Currency)
            {
                 throw new InvalidOperationException("Multi-currency entries are not supported in this version.");
            }
            
            _lines.Add(line);
        }

        /// <summary>
        /// Validates the accounting equation: Sum(Debits) == Sum(Credits).
        /// Throws InvalidOperationException if unbalanced.
        /// </summary>
        public void Validate()
        {
            if (!_lines.Any())
                throw new InvalidOperationException("Journal entry must have lines.");

            var totalDebit = _lines.Where(l => l.Type == EntryType.Debit).Sum(l => l.Amount.Amount);
            var totalCredit = _lines.Where(l => l.Type == EntryType.Credit).Sum(l => l.Amount.Amount);

            if (totalDebit != totalCredit)
            {
                throw new InvalidOperationException($"Journal Entry is unbalanced. Debits: {totalDebit}, Credits: {totalCredit}");
            }
        }
    }
}
