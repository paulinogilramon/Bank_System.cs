namespace SistemaBancario.Core.Domain.Accounting
{
    public enum AccountType
    {
        Asset,      // Activo (e.g., Cash, Loans Receivable)
        Liability,  // Pasivo (e.g., Customer Deposits)
        Equity,     // Patrimonio
        Revenue,    // Ingresos (e.g., Interest Income)
        Expense     // Gastos (e.g., Interest Expense)
    }
}
