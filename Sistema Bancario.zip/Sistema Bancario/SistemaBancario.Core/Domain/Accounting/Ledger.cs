using System;
using System.Collections.Generic;
using System.Linq;
using SistemaBancario.Core.Domain.ValueObjects;

namespace SistemaBancario.Core.Domain.Accounting
{
    public class Ledger
    {
        private readonly List<JournalEntry> _entries = new List<JournalEntry>();
        private readonly object _lock = new object();

        public void Post(JournalEntry entry)
        {
            if (entry == null) throw new ArgumentNullException(nameof(entry));

            lock (_lock)
            {
                // strictly enforce validation before committing to the ledger
                entry.Validate();
                _entries.Add(entry);
            }
        }

        public Money GetBalance(Guid accountId, AccountType accountType)
        {
            lock (_lock)
            {
                var relevantLines = _entries
                    .SelectMany(e => e.Lines)
                    .Where(l => l.AccountId == accountId)
                    .ToList();

                if (!relevantLines.Any())
                    return Money.Zero(); // Assuming USD default, might need to infer currency

                var currency = relevantLines.First().Amount.Currency;
                decimal balance = 0;

                foreach (var line in relevantLines)
                {
                    // Basic accounting accounting equation for balances:
                    // Asset/Expense: Debit increases, Credit decreases
                    // Liability/Equity/Revenue: Credit increases, Debit decreases
                    
                    bool isDebitLength = line.Type == EntryType.Debit;
                    
                    if (accountType == AccountType.Asset || accountType == AccountType.Expense)
                    {
                        balance += isDebitLength ? line.Amount.Amount : -line.Amount.Amount;
                    }
                    else
                    {
                        balance += isDebitLength ? -line.Amount.Amount : line.Amount.Amount;
                    }
                }

                return new Money(balance, currency);
            }
        }
    }
}
