using System;
using SistemaBancario.Core.Domain.ValueObjects;

namespace SistemaBancario.Core.Domain.Accounting
{
    public enum EntryType { Debit, Credit }

    public class EntryLine
    {
        public Guid AccountId { get; }
        public Money Amount { get; }
        public EntryType Type { get; }

        public EntryLine(Guid accountId, Money amount, EntryType type)
        {
            if (accountId == Guid.Empty)
                throw new ArgumentException("Account ID cannot be empty.", nameof(accountId));
            
            if (amount.Amount < 0)
                throw new ArgumentException("Entry amount cannot be negative.", nameof(amount));

            AccountId = accountId;
            Amount = amount;
            Type = type;
        }
    }
}
