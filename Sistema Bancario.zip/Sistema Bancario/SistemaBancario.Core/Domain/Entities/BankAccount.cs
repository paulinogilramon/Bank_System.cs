using System;
using SistemaBancario.Core.Domain.Accounting;
using SistemaBancario.Core.Domain.Services;
using SistemaBancario.Core.Domain.ValueObjects;

namespace SistemaBancario.Core.Domain.Entities
{
    public class BankAccount
    {
        public Guid Id { get; }
        public string AccountNumber { get; }
        private readonly Ledger _ledger;

        // In a real app, these would come from a configuration service
        private readonly Guid _bankCashAccountId; 
        private readonly Guid _interestExpenseAccountId;
        private readonly Guid _taxLiabilityAccountId;

        public BankAccount(
            string accountNumber, 
            Ledger ledger, 
            Guid bankCashAccountId, 
            Guid interestExpenseAccountId,
            Guid taxLiabilityAccountId)
        {
            if (string.IsNullOrWhiteSpace(accountNumber)) throw new ArgumentException("Account Number required.");
            if (ledger == null) throw new ArgumentNullException(nameof(ledger));

            Id = Guid.NewGuid();
            AccountNumber = accountNumber;
            _ledger = ledger;
            _bankCashAccountId = bankCashAccountId;
            _interestExpenseAccountId = interestExpenseAccountId;
            _taxLiabilityAccountId = taxLiabilityAccountId;
        }

        public Money GetBalance()
        {
            // For the bank, this account is a Liability (money owed to customer).
            // So we query the Liability balance.
            return _ledger.GetBalance(Id, AccountType.Liability);
        }

        public void Deposit(Money amount, string description = "Deposit")
        {
            if (amount.Amount <= 0) throw new ArgumentException("Deposit amount must be positive.");

            var entry = new JournalEntry(description, DateTime.UtcNow);
            
            // Bank receives Cash (Asset) -> Debit
            entry.AddLine(new EntryLine(_bankCashAccountId, amount, EntryType.Debit));
            
            // Customer balance increases (Liability) -> Credit
            entry.AddLine(new EntryLine(Id, amount, EntryType.Credit));

            _ledger.Post(entry);
        }

        public void Withdraw(Money amount)
        {
             if (amount.Amount <= 0) throw new ArgumentException("Withdraw amount must be positive.");
             
             var currentBalance = GetBalance();
             if (currentBalance < amount)
                 throw new InvalidOperationException("Insufficient funds.");

             var entry = new JournalEntry("Withdrawal", DateTime.UtcNow);

             // Customer balance decreases (Liability) -> Debit
             entry.AddLine(new EntryLine(Id, amount, EntryType.Debit));

             // Bank Cash decreases (Asset) -> Credit
             entry.AddLine(new EntryLine(_bankCashAccountId, amount, EntryType.Credit));

             _ledger.Post(entry);
        }

        public void ApplyInterest(InterestService interestService, TaxService taxService, InterestRate rate, double timeInYears, CompoundingFrequency frequency)
        {
            var principal = GetBalance();
            if (principal.Amount <= 0) return;

            var interestEarned = interestService.CalculateCompoundInterest(principal, rate, timeInYears, frequency);
            if (interestEarned.Amount == 0) return;

            var tax = taxService.CalculateTax(interestEarned);
            var netInterest = interestEarned - tax;

            // Transaction: Pay Interest
            // 3 legs:
            // 1. Expense (Bank Interest Expense) -> Debit Full Interest Amount
            // 2. Liability (Tax Payable) -> Credit Tax Amount
            // 3. Liability (Customer Account) -> Credit Net Interest Amount

            var entry = new JournalEntry("Interest Payment", DateTime.UtcNow);
            
            // Debit Expenses
            entry.AddLine(new EntryLine(_interestExpenseAccountId, interestEarned, EntryType.Debit));
            
            // Credit Tax
            if (tax.Amount > 0)
            {
                entry.AddLine(new EntryLine(_taxLiabilityAccountId, tax, EntryType.Credit));
            }
            
            // Credit Customer
            entry.AddLine(new EntryLine(Id, netInterest, EntryType.Credit));

            _ledger.Post(entry);
        }
    }
}
