using System;

namespace SistemaBancario.Core.Domain.ValueObjects
{
    /// <summary>
    /// Represents a monetary value with a specific currency.
    /// Immutable struct to prevent side effects and ensure thread safety.
    /// </summary>
    public readonly struct Money : IEquatable<Money>, IComparable<Money>
    {
        public decimal Amount { get; }
        public string Currency { get; }

        public Money(decimal amount, string currency = "USD")
        {
            if (string.IsNullOrWhiteSpace(currency))
                throw new ArgumentException("Currency cannot be empty.", nameof(currency));

            Amount = amount;
            Currency = currency.ToUpperInvariant();
        }

        public static Money Zero(string currency = "USD") => new Money(0m, currency);

        public static Money operator +(Money a, Money b)
        {
            if (a.Currency != b.Currency)
                throw new InvalidOperationException($"Cannot add different currencies: {a.Currency} and {b.Currency}");

            return new Money(a.Amount + b.Amount, a.Currency);
        }

        public static Money operator -(Money a, Money b)
        {
            if (a.Currency != b.Currency)
                throw new InvalidOperationException($"Cannot subtract different currencies: {a.Currency} and {b.Currency}");

            return new Money(a.Amount - b.Amount, a.Currency);
        }

        public static Money operator *(Money a, decimal multiplier) => new Money(a.Amount * multiplier, a.Currency);

        // Comparison operators
        public static bool operator >(Money a, Money b) => a.Amount > b.Amount && a.Currency == b.Currency;
        public static bool operator <(Money a, Money b) => a.Amount < b.Amount && a.Currency == b.Currency;
        public static bool operator >=(Money a, Money b) => a.Amount >= b.Amount && a.Currency == b.Currency;
        public static bool operator <=(Money a, Money b) => a.Amount <= b.Amount && a.Currency == b.Currency;

        public bool Equals(Money other) => Amount == other.Amount && Currency == other.Currency;
        public override bool Equals(object? obj) => obj is Money other && Equals(other);
        public override int GetHashCode() => HashCode.Combine(Amount, Currency);
        public override string ToString() => $"{Amount:N2} {Currency}";

        public int CompareTo(Money other)
        {
            if (Currency != other.Currency)
                throw new InvalidOperationException("Cannot compare different currencies.");
            return Amount.CompareTo(other.Amount);
        }
    }
}
