using System;

namespace SistemaBancario.Core.Domain.ValueObjects
{
    public readonly struct InterestRate
    {
        /// <summary>
        /// The annual interest rate as a decimal (e.g., 0.05 for 5%).
        /// </summary>
        public decimal Value { get; }

        public InterestRate(decimal value)
        {
            if (value < 0)
                throw new ArgumentOutOfRangeException(nameof(value), "Interest rate cannot be negative.");
            
            Value = value;
        }

        public decimal ToPercentage() => Value * 100m;

        public static InterestRate FromPercentage(decimal percentage) => new InterestRate(percentage / 100m);

        public decimal GetMonthlyRate() => Value / 12m;
        public decimal GetDailyRate() => Value / 365m;

        public override string ToString() => $"{ToPercentage():N2}%";
    }
}
