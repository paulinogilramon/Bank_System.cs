﻿using System;
using SistemaBancario.Core.Domain.Accounting;
using SistemaBancario.Core.Domain.Entities;
using SistemaBancario.Core.Domain.Services;
using SistemaBancario.Core.Domain.ValueObjects;

namespace SistemaBancario.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var writer = new System.IO.StreamWriter("output_log.txt"))
            {
                // Helper to dual-log
                void Log(string msg = "") { 
                    Console.WriteLine(msg); 
                    writer.WriteLine(msg); 
                }

                Log("==================================================");
                Log("   SECURE BANKING SYSTEM (DOUBLE-ENTRY KERNEL)    ");
                Log("==================================================");

                // 1. Setup Infrastructure
                var ledger = new Ledger();
                var bankCashId = Guid.NewGuid();
                var taxLiabilityId = Guid.NewGuid();
                var interestExpenseId = Guid.NewGuid();

                // Services
                var interestService = new InterestService();
                var taxService = new TaxService(0.15m); // 15% Tax

                Log($"[Init] Ledger Initialized.");
                Log($"[Init] Institutional Accounts Created:");
                Log($"   - Bank Cash (Asset): {bankCashId}");
                Log($"   - Tax Payable (Liability): {taxLiabilityId}");
                Log($"   - Interest Expense (Expense): {interestExpenseId}");
                Log("");

                // 2. Open User Account
                var userAccount = new BankAccount("USER-001", ledger, bankCashId, interestExpenseId, taxLiabilityId);
                Log($"[Action] Opened Account {userAccount.AccountNumber} (ID: {userAccount.Id})");
                Log($"[State] Initial Balance: {userAccount.GetBalance()}");
                Log("");

                // 3. Deposit Money
                var depositAmount = new Money(1000m, "USD");
                Log($"[Action] Depositing {depositAmount}...");
                userAccount.Deposit(depositAmount, "Initial Deposit");
                Log($"[State] New Balance: {userAccount.GetBalance()}");
                
                // Verify Bank Cash
                var bankCash = ledger.GetBalance(bankCashId, AccountType.Asset);
                Log($"[Audit] Bank Cash Reserve: {bankCash}");
                Log("");

                // 4. Simulate Interest (1 Month later)
                Log("[Time Travel] Fast forwarding 1 month...");
                var rate = InterestRate.FromPercentage(5m); // 5% APR
                Log($"[Action] Applying Interest (Rate: {rate}, Freq: Monthly)...");
                
                userAccount.ApplyInterest(interestService, taxService, rate, 1.0/12.0, CompoundingFrequency.Monthly);
                
                Log($"[State] Customer Balance after Interest: {userAccount.GetBalance()}");
                Log("");

                // 5. Final Audit / Balance Sheet
                Log("==================================================");
                Log("           FINAL BALANCE SHEET (AUDIT)            ");
                Log("==================================================");
                
                var endingCash = ledger.GetBalance(bankCashId, AccountType.Asset);
                var customerLiability = ledger.GetBalance(userAccount.Id, AccountType.Liability);
                var taxLiability = ledger.GetBalance(taxLiabilityId, AccountType.Liability);
                var interestExp = ledger.GetBalance(interestExpenseId, AccountType.Expense);

                Log($"ASSETS:");
                Log($"  Cash in Vault:       {endingCash}");
                
                Log($"LIABILITIES (Owed to others):");
                Log($"  Customer Deposits:   {customerLiability}");
                Log($"  Tax Payable (Govt):  {taxLiability}");
                
                Log($"EQUITY/EXPENSES:");
                Log($"  Interest Expense:    {interestExp}");
                
                Log("--------------------------------------------------");
                
                decimal totalDebits = endingCash.Amount + interestExp.Amount;
                decimal totalCredits = customerLiability.Amount + taxLiability.Amount;
                
                Log($"TOTAL DEBITS (Assets+Exp): {totalDebits:N2}");
                Log($"TOTAL CREDITS (Liab+Eq):   {totalCredits:N2}");
                
                if (totalDebits == totalCredits)
                {
                    Log("\n[SUCCESS] BOOKS ARE BALANCED.");
                }
                else
                {
                    Log("\n[CRITICAL] BOOKS ARE UNBALANCED!");
                }
                Log("==================================================");
            }
        }
    }
}
