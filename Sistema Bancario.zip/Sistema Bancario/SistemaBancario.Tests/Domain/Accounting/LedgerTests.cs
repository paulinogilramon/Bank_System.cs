using System;
using SistemaBancario.Core.Domain.Accounting;
using SistemaBancario.Core.Domain.ValueObjects;
using Xunit;

namespace SistemaBancario.Tests.Domain.Accounting
{
    public class LedgerTests
    {
        [Fact]
        public void Post_UnbalancedEntry_ShouldThrow()
        {
            var ledger = new Ledger();
            var entry = new JournalEntry("Unbalanced", DateTime.UtcNow);
            
            // Debit 100, no Credit
            entry.AddLine(new EntryLine(Guid.NewGuid(), new Money(100m), EntryType.Debit));

            Assert.Throws<InvalidOperationException>(() => ledger.Post(entry));
        }

        [Fact]
        public void Post_BalancedEntry_ShouldSucceed()
        {
            var ledger = new Ledger();
            var entry = new JournalEntry("Deposit", DateTime.UtcNow);
            
            var cashAccountId = Guid.NewGuid();
            var userAccountId = Guid.NewGuid();

            // Debit Cash (Asset) 100
            entry.AddLine(new EntryLine(cashAccountId, new Money(100m), EntryType.Debit));
            // Credit UseAccount (Liability) 100
            entry.AddLine(new EntryLine(userAccountId, new Money(100m), EntryType.Credit));

            ledger.Post(entry);

            // Verify Balances
            // Cash is Asset -> Debit increases it
            Assert.Equal(new Money(100m), ledger.GetBalance(cashAccountId, AccountType.Asset));
            // UserAccount is Liability -> Credit increases it
            Assert.Equal(new Money(100m), ledger.GetBalance(userAccountId, AccountType.Liability));
        }

         [Fact]
        public void Balance_ShouldUpdateCorrectly_AfterMultipleEntries()
        {
            var ledger = new Ledger();
            var accountId = Guid.NewGuid(); // Asset account

            // 1. Initial Debit 100
            var entry1 = new JournalEntry("Init", DateTime.UtcNow);
            entry1.AddLine(new EntryLine(accountId, new Money(100m), EntryType.Debit));
            entry1.AddLine(new EntryLine(Guid.NewGuid(), new Money(100m), EntryType.Credit)); // Offset
            ledger.Post(entry1);

            // 2. Spend 30 (Credit)
            var entry2 = new JournalEntry("Spend", DateTime.UtcNow);
            entry2.AddLine(new EntryLine(accountId, new Money(30m), EntryType.Credit));
            entry2.AddLine(new EntryLine(Guid.NewGuid(), new Money(30m), EntryType.Debit)); // Offset
            ledger.Post(entry2);

            // 3. Receive 50 (Debit)
            var entry3 = new JournalEntry("Receive", DateTime.UtcNow);
            entry3.AddLine(new EntryLine(accountId, new Money(50m), EntryType.Debit));
            entry3.AddLine(new EntryLine(Guid.NewGuid(), new Money(50m), EntryType.Credit)); // Offset
            ledger.Post(entry3);

            // Expected: 100 - 30 + 50 = 120
            Assert.Equal(new Money(120m), ledger.GetBalance(accountId, AccountType.Asset));
        }
    }
}
