using System;
using SistemaBancario.Core.Domain.Services;
using SistemaBancario.Core.Domain.ValueObjects;
using Xunit;

namespace SistemaBancario.Tests.Domain.Services
{
    public class InterestAndTaxTests
    {
        [Fact]
        public void CalculateCompoundInterest_ShouldBeCorrect()
        {
            // Scenario: 1000 USD, 5% annual rate, compounded monthly, for 1 year.
            // Formula: 1000 * (1 + 0.05/12)^(12*1)
            // 1000 * (1 + 0.0041666...)^12
            // 1000 * 1.05116...
            // Total = 1051.16
            // Interest = 51.16

            var checkService = new InterestService();
            var principal = new Money(1000m, "USD");
            var rate = InterestRate.FromPercentage(5m); // 5%

            var result = checkService.CalculateCompoundInterest(principal, rate, 1.0, CompoundingFrequency.Monthly);

            Assert.Equal(51.16m, result.Amount);
        }

        [Fact]
        public void CalculateTax_ShouldApplyRate()
        {
            var taxService = new TaxService(0.10m); // 10%
            var earnings = new Money(50.00m, "USD");
            
            var tax = taxService.CalculateTax(earnings);
            
            Assert.Equal(5.00m, tax.Amount);
        }
    }
}
