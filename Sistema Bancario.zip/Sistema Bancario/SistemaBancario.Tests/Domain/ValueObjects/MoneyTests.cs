using System;
using SistemaBancario.Core.Domain.ValueObjects;
using Xunit;

namespace SistemaBancario.Tests.Domain.ValueObjects
{
    public class MoneyTests
    {
        [Fact]
        public void Constructor_ShouldSetValuesCorrectly()
        {
            var money = new Money(100.50m, "USD");
            Assert.Equal(100.50m, money.Amount);
            Assert.Equal("USD", money.Currency);
        }

        [Fact]
        public void Addition_SameCurrency_ShouldSucceed()
        {
            var m1 = new Money(50m, "USD");
            var m2 = new Money(25m, "USD");
            var result = m1 + m2;
            Assert.Equal(75m, result.Amount);
        }

        [Fact]
        public void Addition_DifferentCurrency_ShouldThrow()
        {
            var m1 = new Money(50m, "USD");
            var m2 = new Money(25m, "EUR");
            Assert.Throws<InvalidOperationException>(() => m1 + m2);
        }

        [Fact]
        public void Subtraction_ShouldSucceed()
        {
            var m1 = new Money(50m, "USD");
            var m2 = new Money(20m, "USD");
            Assert.Equal(30m, (m1 - m2).Amount);
        }
    }
}
