using System;
using SistemaBancario.Core.Domain.Accounting;
using SistemaBancario.Core.Domain.Entities;
using SistemaBancario.Core.Domain.Services;
using SistemaBancario.Core.Domain.ValueObjects;
using Xunit;

namespace SistemaBancario.Tests.Domain.Entities
{
    public class BankAccountTests
    {
        [Fact]
        public void FullFlow_Deposit_Withdraw_Interest_ShouldBeCorrect()
        {
            // Setup Services
            var ledger = new Ledger();
            var interestService = new InterestService();
            var taxService = new TaxService(0.20m); // 20% Tax

            // Setup Bank IDs
            var bankCashId = Guid.NewGuid();
            var interestExpenseId = Guid.NewGuid();
            var taxLiabilityId = Guid.NewGuid();

            var account = new BankAccount("123456", ledger, bankCashId, interestExpenseId, taxLiabilityId);

            // 1. Deposit 1000
            account.Deposit(new Money(1000m, "USD"));
            Assert.Equal(new Money(1000m, "USD"), account.GetBalance());

            // 2. Withdraw 200
            account.Withdraw(new Money(200m, "USD"));
            Assert.Equal(new Money(800m, "USD"), account.GetBalance());

            // 3. Apply Interest
            // Principal: 800
            // Rate: 10%
            // Time: 1 year, Monthly Compounding
            // Interest = 800 * (1 + 0.10/12)^12 - 800
            // 800 * (1.00833)^12 = 800 * 1.1047 = 883.76
            // Interest = 83.76 (approx)
            
            // Re-calc exact expected:
            var rate = InterestRate.FromPercentage(10m);
            var interestAmount = interestService.CalculateCompoundInterest(new Money(800m, "USD"), rate, 1.0, CompoundingFrequency.Monthly);
            // Tax: 20% of Interest
            var taxAmount = taxService.CalculateTax(interestAmount);
            var netInterest = interestAmount - taxAmount;

            account.ApplyInterest(interestService, taxService, rate, 1.0, CompoundingFrequency.Monthly);

            // Verify Customer Balance = 800 + NetInterest
            var expectedBalance = new Money(800m + netInterest.Amount, "USD");
            Assert.Equal(expectedBalance, account.GetBalance());

            // Verify Ledger integrity
            // Bank Interest Expense account should have Debit = interestAmount
            Assert.Equal(interestAmount, ledger.GetBalance(interestExpenseId, AccountType.Expense));
            
            // Tax Liability account should have Credit = taxAmount
            Assert.Equal(taxAmount, ledger.GetBalance(taxLiabilityId, AccountType.Liability));
        }
    }
}
